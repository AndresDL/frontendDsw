import { Component } from '@angular/core';

@Component({
  selector: 'app-followup-treatment',
  templateUrl: './followup-treatment.component.html',
  styleUrl: './followup-treatment.component.scss'
})
export class FollowupTreatmentComponent {

}
