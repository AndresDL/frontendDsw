import { Component } from '@angular/core';

@Component({
  selector: 'app-follow-up',
  templateUrl: './follow-up.component.html',
  styleUrl: './follow-up.component.scss'
})
export class FollowUpComponent {

}
