import { Component } from '@angular/core';

@Component({
  selector: 'app-treatment-price',
  templateUrl: './treatment-price.component.html',
  styleUrl: './treatment-price.component.scss'
})
export class TreatmentPriceComponent {

}
